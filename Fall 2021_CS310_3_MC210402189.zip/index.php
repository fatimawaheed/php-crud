<!DOCTYPE html>
<html lang="en">
    <?php include "header.php" ?>
<body>
    <div class="container border border-success mt-5">
        <h1 class="text-center">Fatima Waheed - Assignment No. 3</h1>
        <ul>
            <li>
                <a href="login.php">
                    <u>Login</u>
                </a>
            </li>
            <li>
                <a href="signup.php">Signup</a>
            </li>
        </ul>
    </div>
</body>